package com.muaz.notch

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.View
import android.view.WindowManager

class NotchService : Service() {
    private var windowManager: WindowManager? = null
    private var notchView: View? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !android.provider.Settings.canDrawOverlays(this)) {
            stopSelf()
            return START_NOT_STICKY
        }

        val notification = buildNotification()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
        showNotch()
        getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE)
            .edit().putBoolean(MainActivity.KEY_ENABLED, true).apply()
        return START_STICKY
    }

    private fun showNotch() {
        if (notchView != null) return
        val metrics = resources.displayMetrics
        val width = (metrics.widthPixels * 0.43f).toInt()
        val height = (36f * metrics.density).toInt()
        val radius = 22f * metrics.density

        val background = GradientDrawable().apply {
            setColor(Color.BLACK)
            // Flat top edge; rounded lower corners, matching the iPhone-style notch silhouette.
            cornerRadii = floatArrayOf(
                0f, 0f, 0f, 0f,
                radius, radius, radius, radius
            )
        }

        val view = View(this).apply {
            setBackground(background)
            contentDescription = "Muaz Notch. Dokunarak uygulamayı aç."
            isClickable = true
            isFocusable = false
            elevation = 18f * metrics.density
            setOnClickListener {
                val launch = Intent(this@NotchService, MainActivity::class.java).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                }
                startActivity(launch)
            }
        }

        val params = WindowManager.LayoutParams(
            width,
            height,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            x = 0
            y = 0
        }

        try {
            windowManager?.addView(view, params)
            notchView = view
        } catch (_: Exception) {
            stopSelf()
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Muaz Notch arka plan hizmeti",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Siyah çentik görünümünü diğer uygulamaların üzerinde tutar."
                setShowBadge(false)
            }
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager)
                .createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val openApp = Intent(this, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        }
        val pending = PendingIntent.getActivity(
            this, 0, openApp,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_notch)
                .setContentTitle("Muaz Notch açık")
                .setContentText("Siyah çentik ekranın üzerinde gösteriliyor.")
                .setContentIntent(pending)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
                .setSmallIcon(R.drawable.ic_notch)
                .setContentTitle("Muaz Notch açık")
                .setContentText("Siyah çentik ekranın üzerinde gösteriliyor.")
                .setContentIntent(pending)
                .setOngoing(true)
                .build()
        }
    }

    override fun onDestroy() {
        try {
            notchView?.let { windowManager?.removeView(it) }
        } catch (_: Exception) {
            // The overlay may already have been detached by Android.
        }
        notchView = null
        getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE)
            .edit().putBoolean(MainActivity.KEY_ENABLED, false).apply()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        private const val CHANNEL_ID = "muaz_notch_overlay"
        private const val NOTIFICATION_ID = 333
    }
}
