package com.muaz.notch

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.view.WindowInsets
import android.widget.FrameLayout

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private val prefs by lazy { getSharedPreferences(PREFS, Context.MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(9, 10, 14)
        window.navigationBarColor = android.graphics.Color.rgb(9, 10, 14)

        webView = WebView(this).apply {
            setBackgroundColor(android.graphics.Color.rgb(9, 10, 14))
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = true
            settings.allowContentAccess = false
            settings.setSupportZoom(false)
            settings.builtInZoomControls = false
            // Keep web content clear of system bars on Android versions that draw edge-to-edge.
            setOnApplyWindowInsetsListener { view, insets ->
                val topInset: Int
                val bottomInset: Int
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    topInset = insets.getInsets(WindowInsets.Type.statusBars()).top
                    bottomInset = insets.getInsets(WindowInsets.Type.navigationBars()).bottom
                } else {
                    @Suppress("DEPRECATION")
                    val legacyTop = insets.systemWindowInsetTop
                    @Suppress("DEPRECATION")
                    val legacyBottom = insets.systemWindowInsetBottom
                    topInset = legacyTop
                    bottomInset = legacyBottom
                }
                view.setPadding(0, topInset, 0, bottomInset)
                insets
            }
            webViewClient = object : WebViewClient() {
                override fun onPageFinished(view: WebView?, url: String?) {
                    syncWebState()
                }
            }
            webChromeClient = WebChromeClient()
            addJavascriptInterface(NativeBridge(), "Native")
            loadUrl("file:///android_asset/index.html")
        }
        setContentView(FrameLayout(this).apply {
            setBackgroundColor(android.graphics.Color.rgb(9, 10, 14))
            addView(webView, FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            ))
        })
    }

    override fun onResume() {
        super.onResume()
        val pending = prefs.getBoolean(KEY_PENDING_ENABLE, false)
        if (pending) {
            prefs.edit().putBoolean(KEY_PENDING_ENABLE, false).apply()
            if (canDrawOverlays()) startNotchService()
        }
        syncWebState()
    }

    override fun onDestroy() {
        if (::webView.isInitialized) {
            webView.removeJavascriptInterface("Native")
            webView.stopLoading()
            webView.destroy()
        }
        super.onDestroy()
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }

    private fun canDrawOverlays(): Boolean =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(this)

    private fun startNotchService() {
        if (!canDrawOverlays()) return
        val intent = Intent(this, NotchService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent) else startService(intent)
        prefs.edit().putBoolean(KEY_ENABLED, true).apply()
        syncWebState(true)
    }

    private fun stopNotchService() {
        stopService(Intent(this, NotchService::class.java))
        prefs.edit().putBoolean(KEY_ENABLED, false).apply()
        syncWebState(false)
    }

    private fun syncWebState(force: Boolean? = null) {
        if (!::webView.isInitialized) return
        val enabled = force ?: (prefs.getBoolean(KEY_ENABLED, false) && canDrawOverlays())
        webView.post {
            if (::webView.isInitialized) {
                webView.evaluateJavascript("window.onNotchChanged && window.onNotchChanged(${enabled})", null)
            }
        }
    }

    private inner class NativeBridge {
        @JavascriptInterface
        fun requestOverlayPermission() {
            runOnUiThread {
                if (canDrawOverlays()) {
                    startNotchService()
                } else {
                    prefs.edit().putBoolean(KEY_PENDING_ENABLE, true).apply()
                    val permissionIntent = Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")
                    )
                    @Suppress("DEPRECATION")
                    startActivityForResult(permissionIntent, REQUEST_OVERLAY)
                }
            }
        }

        @JavascriptInterface
        fun disableOverlay() {
            runOnUiThread { stopNotchService() }
        }

        @JavascriptInterface
        fun isOverlayActive(): Boolean = prefs.getBoolean(KEY_ENABLED, false) && canDrawOverlays()

        @JavascriptInterface
        fun previewNotch() {
            // Preview is shown inside the app. The persistent overlay is enabled only by the main switch.
        }
    }

    companion object {
        const val PREFS = "muaz_notch_settings"
        const val KEY_ENABLED = "notch_enabled"
        const val KEY_PENDING_ENABLE = "pending_enable"
        private const val REQUEST_OVERLAY = 401
    }
}
