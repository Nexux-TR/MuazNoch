@echo off
setlocal
set "APP_HOME=%~dp0"
set "GRADLE_VERSION=8.11.1"
if "%GRADLE_USER_HOME%"=="" set "GRADLE_USER_HOME=%USERPROFILE%\.gradle"
set "BOOTSTRAP_HOME=%GRADLE_USER_HOME%\muaznotch-bootstrap"
set "GRADLE_HOME=%BOOTSTRAP_HOME%\gradle-%GRADLE_VERSION%"
set "GRADLE_BIN=%GRADLE_HOME%\bin\gradle.bat"
if not exist "%GRADLE_BIN%" (
  if not exist "%BOOTSTRAP_HOME%" mkdir "%BOOTSTRAP_HOME%"
  set "ARCHIVE=%BOOTSTRAP_HOME%\gradle-%GRADLE_VERSION%-bin.zip"
  if not exist "%ARCHIVE%" (
    powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-WebRequest 'https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip' -OutFile '%BOOTSTRAP_HOME%\gradle-%GRADLE_VERSION%-bin.zip'"
    if errorlevel 1 exit /b 1
  )
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -Force '%BOOTSTRAP_HOME%\gradle-%GRADLE_VERSION%-bin.zip' '%BOOTSTRAP_HOME%'"
  if errorlevel 1 exit /b 1
)
call "%GRADLE_BIN%" -p "%APP_HOME%" %*
exit /b %ERRORLEVEL%
