# Muaz Notch — Android Studio project

Muaz Notch is an offline-first Android app prototype with:
- A pure-black, camera-free overlay notch, sized to about 43% of screen width and 36 dp tall.
- A foreground service so the overlay can remain visible when the app is in the background.
- A calculator. Enter `333` and press `=` to open the hidden arcade.
- Four playable mini-games: Reflex, Number Guess, Tic-Tac-Toe, and Memory Match.

## Build

1. Open this folder in Android Studio (JDK 17; Android SDK Platform 35).
2. Let Android Studio sync the Gradle project and install any requested build tools.
3. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. Install the resulting debug APK on the Android phone.

The project uses Android Gradle Plugin 8.9.2, Kotlin 2.0.21, and Gradle 8.11.1. The included `gradlew` / `gradlew.bat` scripts bootstrap Gradle 8.11.1 on first use (an internet connection is required for that one-time download).

## First launch

1. Open Muaz Notch.
2. Tap **Çentiği etkinleştir**.
3. Android opens the **Display over other apps / Appear on top** permission page. Allow Muaz Notch.
4. Return to Muaz Notch. The black notch appears at the top of the screen.
5. Tap the app's switch to turn it off. The ongoing notification can be tapped to reopen the app.

## Notes

- The overlay is a software-drawn black shape; it does not alter the physical camera cutout or hide it with a camera imitation.
- Android requires the special **Appear on top** permission. The service also keeps an ongoing notification while active.
- The notch is currently fixed at 43% of display width and 36 dp height. Some launchers, status-bar layouts, and manufacturer software may position overlays slightly differently.
- The app does not request internet access, contacts, files, or location.
- This environment did not have an Android SDK/Gradle installation, so an APK could not be compiled or device-tested here. The Android Studio project and standalone browser preview are included.
